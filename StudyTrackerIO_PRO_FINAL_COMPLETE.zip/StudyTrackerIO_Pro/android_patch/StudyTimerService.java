package org.studytracker.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;

public class StudyTimerService extends Service {
    public static final String ACTION_START = "org.studytracker.app.START";
    public static final String ACTION_PAUSE = "org.studytracker.app.PAUSE";
    public static final String ACTION_STOP = "org.studytracker.app.STOP";
    public static final String EXTRA_END_AT = "endAt";
    public static final String EXTRA_SUBJECT = "subject";
    private static final String CHANNEL_ID = "study_timer";
    private static final int NOTIFICATION_ID = 4101;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long endAt = 0L;
    private String subject = "StudyTracker.io";
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            long left = endAt - System.currentTimeMillis();
            if (left <= 0) { complete(); return; }
            updateNotification(left);
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_START.equals(action)) {
            endAt = intent.getLongExtra(EXTRA_END_AT, 0L);
            subject = intent.getStringExtra(EXTRA_SUBJECT);
            if (subject == null || subject.isEmpty()) subject = "StudyTracker.io";
            save(true, false);
            startAsForeground(Math.max(0, endAt - System.currentTimeMillis()));
            handler.removeCallbacks(ticker); handler.post(ticker);
        } else if (ACTION_PAUSE.equals(action)) {
            handler.removeCallbacks(ticker); save(false, false); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        } else if (ACTION_STOP.equals(action)) {
            handler.removeCallbacks(ticker); save(false, false); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        }
        return START_STICKY;
    }

    private void complete() {
        handler.removeCallbacks(ticker);
        save(false, true);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification n=new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Study session completed")
                .setContentText("Your " + subject + " timer is complete.")
                .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL).build();
        nm.notify(NOTIFICATION_ID+1,n);
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
    }

    private void startAsForeground(long left) {
        Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi=PendingIntent.getActivity(this,1,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("StudyTracker.io timer")
                .setContentText(format(left)+" remaining — "+subject)
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIFICATION_ID,n);
    }

    private void updateNotification(long left) {
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pi=PendingIntent.getActivity(this,1,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("StudyTracker.io timer")
                .setContentText(format(left)+" remaining — "+subject)
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW).build();
        nm.notify(NOTIFICATION_ID,n);
    }

    private String format(long ms){ long sec=Math.max(0,(ms+999)/1000); long h=sec/3600,m=(sec%3600)/60,s=sec%60; return h+"h "+String.format(java.util.Locale.US,"%02dm %02ds",m,s); }
    private void save(boolean running, boolean completed){getSharedPreferences("study_timer_native",0).edit().putBoolean("running",running).putBoolean("completed",completed).putLong("endAt",endAt).putString("subject",subject).apply();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Study Timer",NotificationManager.IMPORTANCE_LOW);c.setDescription("Persistent timer while studying");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public IBinder onBind(Intent intent){return null;}
}
