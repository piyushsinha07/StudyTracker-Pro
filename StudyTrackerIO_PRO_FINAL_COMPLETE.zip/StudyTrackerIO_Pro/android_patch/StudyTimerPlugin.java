package org.studytracker.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "StudyTimer")
public class StudyTimerPlugin extends Plugin {
    private static final int REQUEST_NOTIFICATIONS = 9012;

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && getActivity().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            getActivity().requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        long endAt = call.getLong("endAt", 0L);
        if (endAt <= System.currentTimeMillis()) { call.reject("Invalid end time"); return; }
        Intent i = new Intent(getContext(), StudyTimerService.class);
        i.setAction(StudyTimerService.ACTION_START);
        i.putExtra(StudyTimerService.EXTRA_END_AT, endAt);
        i.putExtra(StudyTimerService.EXTRA_SUBJECT, call.getString("subject", "StudyTracker.io"));
        if (android.os.Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(i); else getContext().startService(i);
        call.resolve();
    }

    @PluginMethod
    public void pause(PluginCall call) {
        Intent i = new Intent(getContext(), StudyTimerService.class); i.setAction(StudyTimerService.ACTION_PAUSE);
        getContext().startService(i); call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Intent i = new Intent(getContext(), StudyTimerService.class); i.setAction(StudyTimerService.ACTION_STOP);
        getContext().startService(i); call.resolve();
    }

    @PluginMethod
    public void reset(PluginCall call) {
        Intent i = new Intent(getContext(), StudyTimerService.class); i.setAction(StudyTimerService.ACTION_STOP);
        getContext().startService(i); call.resolve();
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences("study_timer_native", 0);
        JSObject o = new JSObject();
        o.put("running", p.getBoolean("running", false));
        o.put("endAt", p.getLong("endAt", 0L));
        o.put("completed", p.getBoolean("completed", false));
        o.put("subject", p.getString("subject", "StudyTracker.io"));
        call.resolve(o);
    }
}
