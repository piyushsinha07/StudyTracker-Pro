package org.studytracker.app;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;
public class StudyReminderBootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())&&!"android.intent.action.MY_PACKAGE_REPLACED".equals(i.getAction()))return;android.content.SharedPreferences p=c.getSharedPreferences("study_reminder",Context.MODE_PRIVATE);if(p.getBoolean("enabled",false))StudyReminderScheduler.schedule(c,p.getInt("hour",18),p.getInt("minute",0));}}
