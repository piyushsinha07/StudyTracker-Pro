# StudyTracker.io

Developed by **Piyush Kumar Sinha**.

Application ID: `com.piyushsinha.studytracker`
Version: `2.0.0`
